#!/bin/sh

# My first shell script
echo "This is my first shell script!"
