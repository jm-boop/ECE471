#define SENSOR_NAME "/sys/bus/w1/devices/28-0316532a56ff/w1_slave"
